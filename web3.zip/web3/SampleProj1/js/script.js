//document.getElementById("p").innerHTML="Hello ";
document.write("hi");

window.alert("my alert");