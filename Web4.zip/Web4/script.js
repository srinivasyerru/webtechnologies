
function getHeader(){
return "<h1> Main Heading </h1>";

}

function multiply(num1, num2){
return num1*num2;
}

 
