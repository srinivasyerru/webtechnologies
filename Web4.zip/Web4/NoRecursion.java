public class NoRecursion {

  
  private static long factorial(int num){
      long fact =1;
      while(num >0); // 5*4*3*2*1
      fact*= num--;  // fact =fact*num-1; 5*1; fact=5; fact=5*4; fact =20*3; fact =60*2; fact=120*1

      return fact;
  }

    public static void main(String[] args) {

        System.out.println("factorial of 5::" );
       // int max=4;
        System.out.println(NoRecursion.factorial(5));
    }
}
