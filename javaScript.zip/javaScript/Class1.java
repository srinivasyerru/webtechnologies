class Class1{

public void area(){
int l, b;
l=10;
b=20;
double area1=l*b;
System.out.println("area is :: "+area1);

}//area

public void si(){
int p, t, r;
double simpleInterest;

p=200000;
t=24;
r=20;
simpleInterest=(p*t*r)/100;
System.out.println("simpleInterest :: "+simpleInterest);



}//si

}//Class1