class Class2{
public static void main(String[] args){
System.out.println("main starting");





System.out.println("Main ending");
}//main
}//class2